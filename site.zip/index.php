<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="5;url=/php/presentation.php">
    <link rel="stylesheet" href="index.css">
    <title>L'évidence</title>
</head>
<body>
    <div class="logo">
        <a href="/php/presentation.php"><img id="img" src="/logoRestaurant.png" alt="logo entreprise"></a>
    </div>
</body>
</html>