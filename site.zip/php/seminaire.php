<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/style.css">
    <link rel="stylesheet" href="../css/seminaire.css">
    <title>L'évidence</title>
</head>
<body>
    <header>
        <?php  require 'banniere.php'; ?>
        <?php  require 'header.php'; ?>
    </header>    
    <div class="contenu">
        <p>
            Pour toutes demandes de séminaires, une première prise de contact est à effectuer par : <br><br>
            - téléphone au  02 32 68 20 00<br> 
            - mail à levidence27610@gmail.com <br><br>
            Pour les séminaires il y a possibilité de privatisation de l'établissement à la demi-journée ou à la journée complète avec (pause le matin, repas le midi, pause l'après-midi et repas le soir).<br><br>
             Un devis tarifaire sera effectué selon vos souhaits et vos besoins et devra être validé par signature.
        </p>      
    </div> 
    
    <footer>
        <?php  require 'footer.php'; ?>
    </footer>    
</body>
</html>