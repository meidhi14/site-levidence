
    <div class="menu">
        <nav>
            <ul>
                <li><a href="presentation.php">Présentation</a></li>
                <li class="deroulant"><a href="">Menus</a>
                    <ul class="sous">
                        <li><a href="menu_du_marche.php">Menu du marché</a></li>
                        <li><a href="menu1.php">Menu à 29.90 euros</a></li>
                        <li><a href="menu2.php">Menu à 39.90 euros</a></li>
                        <li><a href="menu_enfant.php">Menu enfant</a></li>
                        <li><a href="carte.php">Carte</a></li>
                    </ul>
                </li>
                <li><a href="seminaire.php">Séminaires d'entreprise</a></li>
                <li><a href="repas_de_groupe.php">Repas de groupe</a></li>    
                <li><a href="contact.php">Contact</a></li>    
            </ul>
        </nav>
    </div>
