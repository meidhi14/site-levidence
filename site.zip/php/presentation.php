<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/style.css">
    <link rel="stylesheet" href="/css/presentation.css">
    <title>L'évidence</title>
</head>
<body>
    <header>
        <?php  require 'banniere.php'; ?>
        <?php  require 'header.php'; ?>
    </header> 

    <p class="textconstruction">Page Web en construction.</p>

    <div class="contenu">

        

        <div class="photo">
            <img  id="photopresentation" src="../presentation.jpg" alt="">
        </div>

        <div class="texte">
            <p>
                Alexis et Claire vous accueillent dans leur restaurant. <br>
                Vous allez y découvrir un lieu totalement à leur image. <br>
                Un lieu chaleureux, une cuisine authentique, raffinée. <br>
                Des produits locaux et de qualité. Un personnel souriant et à l'écoute de ses clients.
            </p>
        </div>

    </div> 

    <footer>
        <?php  require 'footer.php'; ?>
    </footer>

</body>
</html>