<div class="insta">
    <a href="https://www.instagram.com/restaurant_levidence_/?hl=fr"><img src="../logoinsta.png" alt=""></a>
</div>
<div class="facebook">
    <a href="https://www.facebook.com/Restaurant-L%C3%A9vidence-109009328061259"><img src="../logofacebook.png" alt=""></a>
</div>