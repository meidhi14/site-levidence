<div class="banniere">
    
</div>