<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/style.css">
    <link rel="stylesheet" href="../css/contact.css">
    <title>L'évidence</title>
</head>
<body>
    <header>
        <?php  require 'banniere.php'; ?>
        <?php  require 'header.php'; ?>
    </header>   
    <div class="contenu">
        <p>
            Toutes les réservations se font par téléphone au <a href="fax:0232681614">02 32 68 16 14</a> <br>
            Pour toutes questions, vous pouvez nous écrire à l'adresse mail suivante : <a href="mailto:levidence27610@gmail.com">levidence27610@gmail.com</a>        
        </p>      
    </div> 
    
    <footer>
        <?php  require 'footer.php'; ?>
    </footer>  
</body>
</html>