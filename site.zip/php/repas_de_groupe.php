<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/style.css">
    <link rel="stylesheet" href="../css/repas_de_groupe.css">
    <title>L'évidence</title>
</head>
<body>
    <header>
        <?php  require 'banniere.php'; ?>
        <?php  require 'header.php'; ?>
    </header>    
    <div class="contenu">
        <p>
            Les repas de groupes sont les bienvenus dans notre établissement.<br>
            Il suffit simplement de nous contacter soit par téléphone au 02 32 68 16 14 , soit par mail à l'adresse suivante : levidence27610@gmail.com.<br>
            Nous prendrons alors rendez-vous si possible et nous établirons ensuite un menu et une organisation qui conviendra à tout le monde.<br>
            Un devis tarifaire sera alors réalisé et devra être validé par une signature.        </p>      
    </div> 
    
    <footer>
        <?php  require 'footer.php'; ?>
    </footer>    
</body>
</html>