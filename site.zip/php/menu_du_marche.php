<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/style.css">
    <link rel="stylesheet" href="/css/menu_du_marche.css">
    <title>L'évidence</title>
</head>
<body>
    <header>
        <?php  require 'banniere.php'; ?>
        <?php  require 'header.php'; ?>
    </header>  
    <div class="contenu">
        <img src="../menu_du_marche.jpg" alt="">      
    </div> 
    
    <footer>
        <?php  require 'footer.php'; ?>
    </footer>
</body>
</html>